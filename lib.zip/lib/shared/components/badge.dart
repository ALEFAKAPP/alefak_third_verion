// import 'package:flutter/cupertino.dart';
// import 'package:alefakaltawinea_animals_app/shared/components/text.dart';
// import 'package:alefakaltawinea_animals_app/shared/constance/colors.dart';
// import 'package:alefakaltawinea_animals_app/shared/constance/fonts.dart';
//
// Widget BadgeState({title,slug,rudios=10.0,Color color = defaultRed}) {
//   return Container(
//     // width: 80,
//     // height: 22,
//     child: Padding(
//       padding: const EdgeInsets.only(right: 10.0,left: 10.0,top: 5.0,bottom: 5.0),
//       child: Text('$title', style: TextStyle(fontSize: textSizeSSmall,color: color,),textAlign: TextAlign.center,),
//     ),
//     decoration: BoxDecoration(
//       borderRadius: BorderRadius.circular(rudios),
//       color: color.withOpacity(0.15),
//       border: Border.all(color: color)
//     ),
//   );
// }
//
// Widget BadgeBorder({title,rudios=10.0,color = defaultRed,width = 70}) {
//   return Container(
//     // width: width,
//     // height: 18,
//     child: Padding(
//       padding: const EdgeInsets.only(right: 10.0,left: 10.0,top: 5.0,bottom: 5.0),
//       child: Text('$title', style: TextStyle(fontSize: 11,color: primaryColor2,),textAlign: TextAlign.center,),
//     ),
//     decoration: BoxDecoration(
//       borderRadius: BorderRadius.circular(rudios),
//       color: color.withOpacity(0.2),
//       border: Border.all(color: color)
//     ),
//   );
// }
