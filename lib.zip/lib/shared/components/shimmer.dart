// import 'package:hafiz/shared/constance/size.dart';
// import 'package:flutter/material.dart';
//
// Widget titleSmShimmer() => Container(height: 5,width: widthScreenSize(0.10),color: Colors.white,);
// Widget titleMdShimmer() => Container(height: 5,width: widthScreenSize(0.20),color: Colors.white,);
// Widget titleLgShimmer() => Container(height: 5,width: widthScreenSize(0.40),color: Colors.white,);
// Widget titleXLgShimmer() => Container(height: 5,width: widthScreenSize(0.50),color: Colors.white,);
// Widget imageCardHomeShimmer() => Container(height: 180,width: widthScreenSize(0.35),color: Colors.white,);