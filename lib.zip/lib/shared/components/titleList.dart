// import 'package:flutter/material.dart';
// import 'package:hafiz/shared/constance/colors.dart';
//
// import '../constance/fonts.dart';
//
// class TitleListDefault extends StatelessWidget {
//   String? title ;
//   Widget?  leading;
//   Widget ? trailing;
//   Widget ? subtitle;
//   Function() ? onTap;
//   TitleListDefault({this.title,this.leading,this.trailing,this.subtitle,this.onTap});
//
//   @override
//   Widget build(BuildContext context) {
//     return ListTile(
//       title: Text('$title',style: TextStyle(fontSize: textSizeSMedium,fontWeight: FontWeight.bold,color: textSecondaryColor),),
//       leading: leading,
//       onTap: onTap,
//       subtitle: subtitle,
//       trailing: trailing,
//     );
//   }
// }
