
import 'package:alefakaltawinea_animals_app/app_config.dart';

const loginApi = urlApiLocal + "auth/signin";
