class Res{
  static String APP_LOGO_DARK="assets/images/logo_dark.png";
  static String APP_LOGO_NAME="assets/images/logo_name.png";
  static String IC_HOME_GREY="assets/images/ic_home_grey.png";
  static String IC_HOME_BLUE="assets/images/ic_home_blue.png";
  static String IC_FAV_GREY="assets/images/ic_fav_grey.png";
  static String IC_FAV_BLUE="assets/images/ic_fav_blue.png";
  static String IC_PROFILE_GREY="assets/images/ic_profile_grey.png";
  static String IC_PROFILE_BLUE="assets/images/ic_profile_blue.png";
  static String IC_NOTIFICATIONS_GREY="assets/images/ic_notifications_grey.png";
  static String IC_NOTIFICATIONS_BLUE="assets/images/ic_notifications_blue.png";
  static String IC_NEAR_GREY="assets/images/ic_near_grey.png";
  static String IC_NEAR_BLUE="assets/images/ic_near_blue.png";
  static String MARKET_IMG="assets/images/market_img.png";
  static String CLINIC_IMG="assets/images/clinic_img.png";
  static String CAR_IMG="assets/images/car_img.png";
  static String CONSULTATION_IMG="assets/images/consultation_img.png";
  static String ADOPTION_IMG="assets/images/adoption_img.png";
  static String OFFER_ICON="assets/images/offer_icon.png";
  static String HOME_CURVE="assets/images/home_curve.png";
  static String SHOP_IC="assets/images/shop_ic.png";
  static String ANIMALS_BG="assets/images/animals_bg.png";
  static String NO_PROFILE_BG="assets/images/no_profile_bg.png";
  static String DEFAULT_ADD_IMAGE="assets/images/add_image.png";
  static String DEFAULT_IMAGE="assets/images/defult_img.png";
  static String LOGO_WITHOUT_NAME="assets/images/logo_new_img.png";
  static String SPLASH_BG="assets/images/spalsh_bg.png";
  static String ONBOARDING_BG="assets/images/onboarding_bg.png";
  static String ADOPTION_NEW_IMAG="assets/images/adoption_new_img.png";




}