class MyFonts extends Object{
  static String VEXA="VEXA";
  static String ALMARIA="ALMARIA";
  static String GRITA_LT="GRITA_LT";
  static String MYRIAD_ARABIC="MYRIAD_ARABIC";
  static String ArabicUiTextLight="ArabicUiTextLight";
  static String VazirBlack="Vazir-Black";

}