
import 'dart:ui';

class C{
   static const Color BASE_BLUE=Color(0xff0ABAB8);
   static const Color BASE_BLUE_WHITE=Color(0xff0ABAB8);
   static const Color ADAPTION_COLOR=Color(0xffF95AD0);
   static const Color CART_COLOR=Color(0xffd7e6f4);
   static const Color BASE_ORANGE=Color(0xffFFC31B);


}