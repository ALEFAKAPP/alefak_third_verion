
import 'package:flutter/cupertino.dart';

class IntroProviderModel with ChangeNotifier {

}