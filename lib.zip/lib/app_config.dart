
const apiPassword = '';
const double APP_VERSION = 1.0;

const urlApiLocal  = "https://alefak.com/api/v2/" ;

const urlApi_host = "" ;
const urlApiAssetsFileLocal = "https://alefak.com/public/";
const urlImage = "https://alefak.com/images/";
const defaultRadius = 5.0;
const defaultRadiusInput = 50.0;
const defaultPadding = 15.0;